import time
from openGLWindow import start_simulation
import traci
import tkinter as tk


# set window parameter
def get_screen_size(window):
    return window.winfo_screenwidth(), window.winfo_screenheight()


def get_window_size(window):
    return window.winfo_reqwidth(), window.winfo_reqheight()


def center_window(root, width, height):
    screenwidth = root.winfo_screenwidth()
    screenheight = root.winfo_screenheight()
    size = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
    # print(size)
    root.geometry(size)


def setWindow():
    root = tk.Tk()
    root.title('Peripheral Information')

    root.geometry("350x80+0+150")
    root.configure(bg='white')

    root.attributes("-topmost", True)

    Entry_1 = tk.Entry(root, text='input your text here', bg="white")
    Entry_1.place(x=130, y=10)

    def reset():
        Entry_1.delete(0, 'end')
        all_vehicle_id = list(traci.vehicle.getIDList())

        for i in all_vehicle_id:
            traci.vehicle.setColor(i, (255, 255, 0))

    Button_1 = tk.Button(root, text="Enter", command=start_simulation, bg="white")
    Button_1.place(x=50, y=40)
    Button_2 = tk.Button(root, text="Reset", command=reset, bg="white")
    Button_2.place(x=160, y=40)
    root.mainloop()  # 进入消息循环
