import threading
import time
from tkinterWindow import setWindow
import traci
import optparse
import os
from tkinter import *

# 验证环境变量
if 'SUMO_HOME' in os.environ:
    tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
    sys.path.append(tools)
else:
    sys.exit("please declare environment variable 'SUMO_HOME'")

from sumolib import checkBinary


def get_options():
    optParser = optparse.OptionParser()
    optParser.add_option("--nogui", action="store_true",
                         default=False, help="run the commandline version of sumo")
    options, args = optParser.parse_args()
    return options


def generate_routeFile():
    options = get_options()
    if options.nogui:
        sumoBinary = checkBinary('sumo')
    else:
        sumoBinary = checkBinary('sumo-gui')
    traci.start(['sumo-gui', "-c", "suzhouMap.sumocfg"])  # 打开对应的sumo文件

    step = 0

    while step < 360000:
        # time.sleep(1)
        traci.simulationStep()
        step += 1

        all_vehicle_id = traci.vehicle.getIDList()  # 输出当前画面所有车辆ID
        # print(all_vehicle_id)

        if step == 36:

            target_vehicle_id = 'veh0'  # 要获取信息的目标车辆ID
            print()
            print('################## target car information ######')
            position = traci.vehicle.getPosition(target_vehicle_id)
            position3D = traci.vehicle.getPosition3D(target_vehicle_id)
            angle = traci.vehicle.getAngle(target_vehicle_id)
            # 车辆信号灯状况，对应https://sumo.dlr.de/docs/TraCI/Vehicle_Signalling.html
            signals = traci.vehicle.getSignals(target_vehicle_id)
            print('###### type:', traci.vehicle.getTypeID(target_vehicle_id))
            print('###### length:', traci.vehicle.getLength(target_vehicle_id), 'm')
            print('###### width:', traci.vehicle.getWidth(target_vehicle_id), 'm')
            print('###### height:', traci.vehicle.getHeight(target_vehicle_id), 'm')
            print('###### color:', traci.vehicle.getColor(target_vehicle_id))
            print('###### mileage:', '%.2f' % traci.vehicle.getDistance(target_vehicle_id), 'm')    # 行车里程
            print('###### speed:', '%.2f' % traci.vehicle.getSpeed(target_vehicle_id), 'm/s')
            print('###### real speed:', '%.2f' % traci.vehicle.getSpeedWithoutTraCI(target_vehicle_id), 'm/s')  # 如果不受traci控制
            print('###### max speed:', '%.2f' % traci.vehicle.getMaxSpeed(target_vehicle_id), 'm/s')
            print('###### maximum acceleration:', '%.2f' % traci.vehicle.getAccel(target_vehicle_id), 'm/s^2')
            print('###### maximum deceleration:', '%.2f' % traci.vehicle.getDecel(target_vehicle_id), 'm/s^2')
            # 一步的燃油量，费电量
            print('###### Fuel Consumption:', '%.2f' % traci.vehicle.getFuelConsumption(target_vehicle_id), 'ml/s')
            print('###### Electricity Consumption:',
                  '%.2f' % traci.vehicle.getElectricityConsumption(target_vehicle_id), 'Wh/s')
            print('###### lateral speed:',
                  '%.2f' % traci.vehicle.getLateralSpeed(target_vehicle_id), 'm/s')
            print('###### acceleration:', '%.2f' % traci.vehicle.getAcceleration(target_vehicle_id), 'm/s^2')
            print()
            print('################## road information ######')
            road_id = traci.vehicle.getRoadID(target_vehicle_id)
            lane_id = traci.vehicle.getLaneID(target_vehicle_id)
            lane_index = traci.vehicle.getLaneIndex(target_vehicle_id)
            route_id = traci.vehicle.getRouteID(target_vehicle_id)
            route_index = traci.vehicle.getRouteIndex(target_vehicle_id)
            edges_made_of_route = traci.vehicle.getRoute(target_vehicle_id)
            lane_position = traci.vehicle.getLanePosition(target_vehicle_id)    # 车前保险杠到所在车道最开始的距离
            print('###### which lane the car in:', lane_index + 1)
            print('###### number of lanes in current road:', traci.edge.getLaneNumber(road_id))
            print('###### current lane length:', traci.lane.getLength(lane_id), 'm')
            print('###### current lane width:', traci.lane.getWidth(lane_id), 'm')
            print()
            print('################## surrounding information ######')
            # traci.vehicle.getNeighbors(target_vehicle_id, 1)
            next_stop = traci.vehicle.getNextStops(target_vehicle_id)
            if not (traci.vehicle.getNextTLS(target_vehicle_id) is None):
                # next_TLS = list(traci.vehicle.getNextTLS(target_vehicle_id))[0][0]
                # edges_made_of_TLS = traci.trafficlight.getControlledLanes(next_TLS)
                print('###### next traffic lights:', traci.vehicle.getNextTLS(target_vehicle_id))
                # print('###### traffic time left:', traci.trafficlight.getNextSwitch(next_TLS)-step)
            if not (traci.vehicle.getLeader(target_vehicle_id) is None):
                print('###### distance of front car:', '%.2f' % traci.vehicle.getLeader(target_vehicle_id)[1], 'm')
            if not (traci.vehicle.getFollower(target_vehicle_id) is None):
                print('###### distance of back car:', '%.2f' % traci.vehicle.getFollower(target_vehicle_id)[1], 'm')

            print()


    traci.close()


if __name__ == "__main__":
    thread1 = threading.Thread(target=setWindow)
    thread2 = threading.Thread(target=generate_routeFile)
    thread2.start()
    time.sleep(0.5)
    thread1.start()
